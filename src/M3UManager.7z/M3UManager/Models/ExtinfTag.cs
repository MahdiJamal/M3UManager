﻿namespace M3UManager.Models;

public class ExtinfTag(ExtinfTagAttributes extinfTagAttributes)
{
    public ExtinfTagAttributes TagAttributes { get; set; } = extinfTagAttributes;
}
